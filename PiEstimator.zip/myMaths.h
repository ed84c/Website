//myMaths.h
//Contains various functions for performaning mathematical calculations

#include <iostream>

using namespace std;

double bisect(double &a,double &b, double c);
double sqrt(double x);
double sin(double theta);
double cos(double theta);
double tan(double theta);

double sqrt(double x2){
double Nmax=1000000, emax=0.0000001, e=99, a=0, b=2, i=0,exitCode;

    while(i<Nmax && e>emax){
                 e = bisect(a,b,x2);
                 i++;
                 }
return (a+b)/2;    
}

double bisect(double &a,double &b,double c){
      double p = (a+b)/2, temp;
      if((c-a*a)*(c - p*p)>0) {
                    a = p;
                    b=b;
                    }
      else{
      b=p;
      a=a;
      }
return (b-a)/2;
}

double sin(double theta){
      const double cos60= 0.5;
      double sin30, sinTheta, cosTheta, currTheta=30;
      
      sin30 = sqrt(0.5*(1-cos60));
      //cout << "Sin 30 " << sin30 << endl;
      sinTheta = sin30;
      while(currTheta > theta){
                       cosTheta = cos(sinTheta);
                       sinTheta = sqrt(0.5*(1-cosTheta)); //This is now theta/2;
                       currTheta = currTheta/2;
                       }
      return sinTheta;
}

double cos(double sinTheta){
//Takes sinTheta an returns cosTheta;
double cosTheta;
cosTheta = sqrt(1-sinTheta*sinTheta);
      return cosTheta;
}

double tan(double theta){
      double tanTheta;
      tanTheta = sin(theta)/cos(sin(theta));
      return tanTheta;
      }

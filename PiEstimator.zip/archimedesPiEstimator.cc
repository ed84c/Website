//archimedesPiEstimator.cc
//Estimates a valule of Pi using the archimedes method

#include<iostream>
#include "myMaths.h"

using namespace std;

int main(){
    int N;
    double pilower, piupper, thetan, twothetan, exitCode;
    
    cout << "Please enter number of triangles" << endl;
    cin >>N;
    
    twothetan = 360.0/N;
    thetan = twothetan/2;
    cout << "Sqrt 0.5^2 " << sqrt(0.5*0.5) << endl;
    cout << "Theta N: " << thetan << endl;
    cout << "Cos theta N: " << cos(sin(thetan)) << endl;
    cout << "Sin theta N: " << sin(thetan) << endl;
    cout << "Tan theta N: " << tan (thetan) << endl;
    
    pilower = N*sin(thetan)*cos(sin(thetan));
    piupper = N*tan(thetan);
    
    cout << "The upper bound of pi is " << piupper << endl;
    cout << "The lower bound of pi is " << pilower << endl;
    cin >> exitCode; 
    return 0;
}

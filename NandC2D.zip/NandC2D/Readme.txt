EFKHunt 2013.

Noughts and Crosses in 2-D, N-D is on its way!

Current configuration is computer vs computer.
function MouseTrack
timerObj = timer('TimerFcn',@timerCallback,'Period',0.5)
start(timerObj)
end

function timerCallback(timerObj,event,str_arg)
% this function is executed every time the timer object triggers

% read the coordinates
coords = get(0,'PointerLocation');
% print the coordinates to screen
fprintf('x: %4i y: %4i\n',coords)

end

function VehiclePlot(N,xLog,xDotLog,u,dt,T,RLine)
%trackPlot(RLine)
xPos = zeros(1,N);
yPos = zeros(1,N);
v = xLog(1,:);
w = xLog(1,:);
u = ones(1,N)*8;

for (i=0:N-2)
xPos(i+2) = xPos(i+1) + u(i+1)*cos(w(i+1))*dt+v(i+1)*sin(w(i+1))*dt;
yPos(i+2) = yPos(i+1) + u(i+1)*sin(w(i+1))*dt-v(i+1)*sin(w(i+1))*dt;
end

t = [0:dt:T];
plot(xPos,yPos,"+");
hold off;
end



function RLine = RacingLine

RLine = load('RLine.csv')

end

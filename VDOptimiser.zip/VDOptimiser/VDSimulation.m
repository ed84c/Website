function VDSimulation
dt = 0.5;
T = 30;
N = int16(T/dt);


delta = zeros(1,N);
LineDiff = DriveTrack(delta,dt,T,N);



end

function LineDiff = DriveTrack(delta,dt,T,N)
[A,B] = StateSpaceMatrices
RLine = RacingLine;

v=0;
w=0;

u=3;
x=[0;0];
x_log = zeros(2,N);
xdot_log = zeros(2,N);
kDriver = 10;

xPos = 0;
yPos = 0;

%trackPlot(RLine);
delta = 0
for(i=0:N-1)
	
	
	xdot = A*x + B*3;
	
	vdot = xdot(1);
	wdot = xdot(2)
	
	v=v+vdot*dt;
	w=w+wdot*dt;

	x = [v;w];
	x_log(:,i+1) = x;
	xdot_log(:,i+1)=xdot;
	
	xPos = xPos + u*cos(w)*dt+v*sin(w)*dt
	yPos = yPos + u*sin(w)*dt-v*sin(w)*dt
	%Global x and y positions
	
	%plot(xPos,yPos,'+')
	plot(i,v)
	hold on;
	plot(i,w)
	
	RLine_y = interp1(RLine(:,1),RLine(:,2),xPos,'nearest',10)
	delta = -(yPos - RLine_y)*kDriver*cos(w)
	
	if delta>2
		delta =3
	end
	
	if delta<-2
		delta = -3
	end
	
end

%VehiclePlot(N,x_log,xdot_log,5,dt,T,RLine)
LineDiff = 0;
end



function [A,B] = StateSpaceMatrices
Cf = 1.4;
Cr = 1;
M=200;
I=180;
u=3;
a=1.4;
b=1.4;

A11 = -(Cf+Cr)/(M*u);
A12 = -(a*Cf-b*Cr)/(M*u)+u;
A21 = -(a*Cf-b*Cr)/(I*u);
A22 = -(a.^2*Cf+b.^2*Cr)/(I*u);

Ksw =1;


B1 = Cf /(M*Ksw);
B2 = a*Cf/(I*Ksw);

A = [A11 A12; A21 A22];
B = [B1;B2];

end

function trackPlot(RLine)
TL = load('RightTrackLine.csv');
TR = load('LeftTrackLine.csv');

TL_x = TL(:,1);
TL_y = TL(:,2);

TR_x = TR(:,1);
TR_y = TR(:,2);

RLine_x = RLine(:,1);
RLine_y = RLine(:,2);
hold on;

hold on;
plot(TR_x,TR_y,"color","black")
plot(TL_x,TL_y,"color","black")
plot(RLine_x,RLine_y,"color","red")

end




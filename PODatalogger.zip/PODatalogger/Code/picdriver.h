#define no_error 0




int init_usb (void);
int close_usb (void);
int read_analog_input (int *value);
int set_led (int value);


int read_TransImpedance (int *value) ;



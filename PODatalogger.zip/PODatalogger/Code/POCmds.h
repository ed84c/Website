
int Read(int * redChn, int * IRChn);
int setLEDReg(int redled, int IRled);
int FingerPresent(void);
int SetIndicators(int indicator, int red, int blue, int green);

//PulseOx Test and development Commands
int setDAC(int setting);

int setPWMRed(int value);
int setPWMIR(int value);

int ReturnADC(int *ADC0, int *ADC1, int *ADC2);

int ReturnRegisters(int *DCbias, int * redSetting, int * IRSetting);

int read_TransImpedance (int *value);
int read_ADC1 (int *value);
int read_Output (int *value);

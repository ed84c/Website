/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2011. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_CMDChooseCSV               2       /* control type: command, callback function: cmdChooseCSV */
#define  PANEL_SetAlarms                  3       /* control type: binary, callback function: SetAlarms */
#define  PANEL_LowerPulse                 4       /* control type: numeric, callback function: LowerPulse */
#define  PANEL_UpperPulse                 5       /* control type: numeric, callback function: UpperPulse */
#define  PANEL_COMMANDOK                  6       /* control type: command, callback function: cmdOK */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK cmdChooseCSV(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK cmdOK(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK LowerPulse(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SetAlarms(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK UpperPulse(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

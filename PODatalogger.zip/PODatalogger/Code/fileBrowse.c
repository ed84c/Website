#include <utility.h>
#include <ansi_c.h>
#include "FileBrowser.h"
#include <cvirte.h>		
#include <userint.h>
#include "fileBrowse.h"

#define FILEBROWSER_ID 9		  

int getFileBrowserIndex(void);
int CVICALLBACK hiddenFileBrowserCB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2);

static int panelHandle;   
static int hiddenFileBrowserIndex=0;
char * file;

int browse_main (/*int argc, char *argv[]*/void){
	
	/*if (InitCVIRTE (0, argv, 0) == 0)
		return -1;
	*/
	if ((panelHandle = LoadPanel (0, "fileBrowse.uir", PANEL)) < 0)
		return -1;
    FileBrowser_Create (panelHandle, PANEL_FILEBROWSER, ROOT_LEVEL_STRING);
	DisplayPanel (panelHandle);
	
	hiddenFileBrowserIndex = getFileBrowserIndex();
	
	InstallCtrlCallback (panelHandle, hiddenFileBrowserIndex, hiddenFileBrowserCB, 0);
	
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK QuitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int index;
	
	switch (event)
	{
		case EVENT_COMMIT:
			
			QuitUserInterface (0);
			break;
	}
	return 0;
}


int CVICALLBACK hiddenFileBrowserCB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int selectedIndex=0;
	file = malloc(sizeof(char) * 200);
	
	switch (event)
	{
		case EVENT_SELECTION_CHANGE:
			
			GetCtrlAttribute (panelHandle, hiddenFileBrowserIndex, ATTR_CTRL_INDEX, &selectedIndex);
			
			GetValueFromIndex(panelHandle, hiddenFileBrowserIndex, selectedIndex, file);			
			
			if(file == NULL){
				
			}
			else{
				SetCtrlVal(panelHandle, PANEL_STRING, file);
			}
			
			break;
	}
	return 0;
}

int getFileBrowserIndex(){
	int controlID, x, style, fileBrowserIndex=0;
	char * tempString = malloc(sizeof(char) * 100); 
	
	GetPanelAttribute (panelHandle, ATTR_PANEL_FIRST_CTRL, &controlID);
	
	while(controlID != 0){
		GetCtrlAttribute (panelHandle, controlID, ATTR_CONSTANT_NAME,
						  tempString);
		
		GetCtrlAttribute (panelHandle, controlID, ATTR_CTRL_STYLE, &style);
		
		if((strlen(tempString) == 0) && (style == 513)){
			// We've found the hidden list box
			fileBrowserIndex = controlID;
			break;
		}
		
		GetCtrlAttribute (panelHandle, controlID, ATTR_NEXT_CTRL, &controlID);
	}	
	return fileBrowserIndex;
}


int CVICALLBACK OKCallback(int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	char * filep;
	filep = malloc(sizeof(char) * 200); 
	switch (event)
	{
	case  EVENT_COMMIT:
		GetCtrlVal(panelHandle,PANEL_STRING, filep);
		write_csv_folder(filep);
		HidePanel(panelHandle);
	break;
	}
return 0;

}

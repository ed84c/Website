/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2011. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANELCAL                         1
#define  PANELCAL_CURREADING              2       /* control type: numeric, callback function: (none) */
#define  PANELCAL_POREADING               3       /* control type: numeric, callback function: (none) */
#define  PANELCAL_NUMPoints               4       /* control type: numeric, callback function: (none) */
#define  PANELCAL_CALPLOT                 5       /* control type: graph, callback function: calplot */
#define  PANELCAL_CALIBRATE               6       /* control type: command, callback function: CAL_CALIBRATE */
#define  PANELCAL_FINISHCAL               7       /* control type: command, callback function: CAL_FINISH */
#define  PANELCAL_TAKEVALUE               8       /* control type: command, callback function: takevalue */
#define  PANELCAL_NumC                    9       /* control type: numeric, callback function: (none) */
#define  PANELCAL_NumM                    10      /* control type: numeric, callback function: (none) */
#define  PANELCAL_TIMER                   11      /* control type: timer, callback function: TIMER_CLICK */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK CAL_CALIBRATE(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CAL_FINISH(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK calplot(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK takevalue(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TIMER_CLICK(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

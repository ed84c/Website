#include "PulseOx_CalHelp.h"
#include "PulseOx_MainHelp.h"
#include "PulseOx_Calibrate.h"
#include <analysis.h>
#include <cvirte.h>		
#include <userint.h>
#include "PulseOx.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "POSigProc.h"
#include "fileBrowse.h"

#include <math.h>


static int panmanhelp;

static int calhelp;

static int panelHandle;

static int pulseMinhere;
static int pulseMaxhere;
static	int limiton = 0;

void Plot_Pulse (double RedY_val, double IRY_val);
void Plot_log (double *LOGarray);
void Open_CSV_Panel(void);
void setupalarm(int setalarm, int pulseMin, int pulseMax);
void Setmc(double m1, double c1);
int LogSet_Main(void);   
int __stdcall Cal_Main (void);
int __stdcall Man_Main (void);


double LOGarray[2];
char filename [FILENAME_MAX];  

int Log_i;
int logging;
int NewFile;
int color;
FILE *f; 
double Complete_Log[2][1000];

static double m;
static double c;


int main ()
{
	char date[9];
	time_t now;

    struct tm *today;  
	
	if ((panelHandle = LoadPanel (0, "PulseOx.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	LoadMenuBar (PANEL,"PulseOx.uir",MENUBAR);

	init_usb();
	Setmc(-30,100);
	RunUserInterface ();
	close_usb();
	
	DiscardPanel (panelHandle);
	ClearStripChart (PANEL, PANEL_PULSEGRAPH);
	SetCtrlAttribute (PANEL, PANEL_PULSEGRAPH, ATTR_NUM_TRACES, 2);
	
	/* SetCtrlAttribute(PANEL, PANEL_STARTLOG, ATTR_VISIBLE, 1);
	SetCtrlAttribute(PANEL, PANEL_STOPLOG, ATTR_VISIBLE, 0);  */
	
	logging =0;
	Log_i = 0;
	NewFile = 1;

	

	
	
	

 
	return 0;
}

int CVICALLBACK startlog_hit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{  
	  /*SetCtrlAttribute(PANEL, PANEL_STARTLOG, ATTR_VISIBLE, 0);
	  SetCtrlAttribute(PANEL, PANEL_STOPLOG, ATTR_VISIBLE, 1);		*/
	
	char date[9];
	time_t now;
	char dateandtime[20];
	
    struct tm *today;  
	
	
	
    //get current date  
    time(&now);  
    today = localtime(&now);

	
	sprintf(filename,"%s%i%i%i%s%i%i%s", "pulseox",today->tm_mday,today->tm_mon+1,today->tm_year-100,"_",today->tm_hour,today->tm_min, ".csv");
	SetCtrlVal(PANEL,PANEL_CSVLOCSTR,filename);
      
	sprintf(dateandtime,"%i%s%i%s%i%s%i%s%i",today->tm_mday,"//", today->tm_mon+1, 
		"//", today->tm_year-100, " ",today->tm_hour, ":", today->tm_min);
	
	switch (event) {
	case EVENT_LEFT_CLICK :
	 	SetCtrlAttribute (PANEL, PANEL_STOPLOG, ATTR_DIMMED,0);  
		SetCtrlAttribute (PANEL, PANEL_STARTLOG, ATTR_DIMMED,1);
		SetCtrlVal (panel, PANEL_LOGGING,1);
		GetCtrlVal(PANEL,PANEL_CSVLOCSTR,filename);
		logging = 1;
		f = fopen(filename, "a");
		fprintf(f, "%s", "EFKHUNT MIWALKER 2011");
		fprintf(f,"\n");
		fprintf(f, dateandtime);
		fprintf(f,"\n");
		fprintf(f, filename);
		fprintf(f,"\n");
  	break;
	}
		  
    return 0;
 
}

int CVICALLBACK CSV_loc   (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_LEFT_CLICK :
		Open_CSV_Panel();
		break;
	}
	return 0;
}

void Open_CSV_Panel(void){
int panelHandle;

panelHandle = LoadPanel (0, "fileBrowse.uir", PANEL);

/* display the panel and run the UI */


browse_main();

/* free resources and return */
DiscardPanel (panelHandle);

CloseCVIRTE ();

}

int CVICALLBACK stoplog_hit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
/*	SetCtrlAttribute(PANEL, PANEL_STARTLOG, ATTR_VISIBLE, 1);
	SetCtrlAttribute(PANEL, PANEL_STOPLOG, ATTR_VISIBLE, 0); */
	
		switch (event) {
	case EVENT_LEFT_CLICK :
	 	  	logging = 0;
			SetCtrlAttribute (PANEL, PANEL_STOPLOG, ATTR_DIMMED,1);
			SetCtrlAttribute (PANEL, PANEL_STARTLOG, ATTR_DIMMED,0);
			SetCtrlVal (panel, PANEL_LOGGING,0);
			fclose(f);
  	break;
	}
;
	return 0;
	
}



void Plot_Pulse (double RedY_val, double IRY_val)
{

	double Pulsearray[2];
	Pulsearray[0]=RedY_val;
	Pulsearray[1]=IRY_val;
	PlotStripChart (PANEL, PANEL_PULSEGRAPH,Pulsearray,2,0,0,VAL_DOUBLE);	  	
		
		
}

void Plot_log(double *LOGarray)
{
	PlotStripChart (PANEL, PANEL_LOGGRAPH,LOGarray,2,0,0,VAL_DOUBLE);	  	
	
}



void Generate_Log(double *LOGarray, int Log_i)
{
	
	Complete_Log[0][Log_i] = LOGarray[0];
	Complete_Log[1][Log_i] = LOGarray[1];
		
}


int write_to_file( double SAO2_val, double Pulse_val ) 
{ 
	int i;

  NewFile =0;
  fprintf(f, "%i,%f,%f", 1, SAO2_val , Pulse_val);
  fprintf(f,"\n");
  fflush(f);
  
  return 0; 
} 


int CVICALLBACK TIMER_DISPLAY (int panel, int control, int event,
void *callbackData, int eventData1, int eventData2)
{	
	double Ros =0.0;
	double PulseRate = 0.0;
	double IRtrace = 0.0;
	double RedTrace = 0.0;
	static int i;
	int intPulseRate;


	
	
	
	if(IsFingerPresent() == 1){
		switch (event) {
			case EVENT_TIMER_TICK:
			  
				if(getPulse(&IRtrace, &RedTrace, &PulseRate, &Ros) == 1){;
	
					if (IsFingerPresent()==1){
						LOGarray[0] = Ros * m + c;
						LOGarray[1] = PulseRate;
	
						Plot_Pulse(RedTrace, IRtrace);
	

						intPulseRate= (int) PulseRate;
						SetCtrlVal (panel, PANEL_PULSE , intPulseRate);
						SetCtrlVal (panel, PANEL_SAO2, Ros * m + c);
						SetCtrlVal (panel, PANEL_ISFINGER,IsFingerPresent());
						

						//printf("%i", pulseMaxhere) ;
						//printf{"%i", pulseMinhere};
						//printf{"%i", limiton};
							
						if(limiton==1)
						{
						SetCtrlAttribute(panel, PANEL_PulseAlarm, ATTR_DIMMED,0);  
						"\a";
						}
						else
						{
						SetCtrlAttribute(panel, PANEL_PulseAlarm ,ATTR_DIMMED,1);  
						}
						
				
						if(limiton==1 && (intPulseRate > pulseMaxhere || intPulseRate < pulseMinhere))
						{
						SetCtrlVal(panel, PANEL_PulseAlarm,1);  
						"\a";
						}
						else
						{
						SetCtrlVal(panel, PANEL_PulseAlarm,0);  
						}
	
						if ((i %100 == 0)){
							Plot_log(LOGarray);
		
							if(logging == 1)write_to_file (Ros, PulseRate);
						}
						i++;
					}
					//i++;
				}
			break;
		}
	}
	return 0;
}



int CVICALLBACK QuitMain  (int panel, int control, int event,
void *callbackData, int eventData1, int eventData2)
{
		int index;
	
	switch (event)
	{
		case EVENT_COMMIT:
			QuitUserInterface (1);
			break;
	}
	return 0;
}

int write_csv_folder(char *filep){
	
	char date[9];
	time_t now;

    struct tm *today;  
	
	
	
    //get current date  
    time(&now);  
    today = localtime(&now);
	
	sprintf(filename,"%s%s%s%i%i%i%s%i%i%s", filep,"\\", "pulseox",today->tm_mday,today->tm_mon+1,today->tm_year-100,"_",today->tm_hour,today->tm_min, ".csv");
	SetCtrlVal(PANEL,PANEL_CSVLOCSTR,filename);
	
	GetCtrlVal(PANEL,PANEL_CSVLOCSTR,filename);

	
	return 0;
}






void CVICALLBACK Menu_Close (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	exit(1);
}

void CVICALLBACK Menu_Refresh (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	ClearStripChart (PANEL, PANEL_PULSEGRAPH); 
	ClearStripChart (PANEL, PANEL_LOGGRAPH);
}



void CVICALLBACK Menu_Logging (int menuBar, int menuItem, void *callbackData,
		int panel)
{

	panelHandle = LoadPanel (0, "PulseOx_LogSettings.uir", PANEL);

/* display the panel and run the UI */

 LogSet_Main();

/* free resources and return */
DiscardPanel (panelHandle);

CloseCVIRTE ();

}

void CVICALLBACK Menu_Help (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	
}

void CVICALLBACK Menu_Help2 (int menuBar, int menuItem, void *callbackData,
		int panel)
{				  int panelHandle;

panelHandle = LoadPanel (0, "PulseOx_MainHelp.uir", PANEL);

/* display the panel and run the UI */

 Man_Main();

/* free resources and return */
DiscardPanel (panelHandle);

CloseCVIRTE ();
}

void CVICALLBACK Menu_Help4 (int menuBar, int menuItem, void *callbackData,
		int panel)
{				  int panelHandle;

panelHandle = LoadPanel (0, "PulseOx_CalHelp.uir", PANEL);

/* display the panel and run the UI */

Cal_Main();

/* free resources and return */
DiscardPanel (panelHandle);

CloseCVIRTE ();
}


void CVICALLBACK Menu_About (int menuBar, int menuItem, void *callbackData,
		int panel)

{
	
}

void Setmc(double m1, double c1){
	m = m1;
	c = c1;
}


int CVICALLBACK cmdquithelp (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			HidePanel(panel); 
			break;
	}
	return 0;
}

int __stdcall Cal_Main (void)
{

	if ((calhelp = LoadPanel (0, "PulseOx_CalHelp.uir", CALHELP)) < 0)
		return -1;
	DisplayPanel (calhelp);
	RunUserInterface ();
	DiscardPanel (calhelp);
	return 0;
}

int __stdcall Man_Main (void)
{

	if ((panmanhelp = LoadPanel (0, "PulseOx_MainHelp.uir", PANMANHELP)) < 0)
		return -1;
	DisplayPanel (panmanhelp);
	RunUserInterface ();
	DiscardPanel (panmanhelp);
	return 0;
}

void setupalarm(int setalarm,int pulseMin, int pulseMax){
	//panelHandle = LoadPanel (0, "PulseOx.uir", PANEL);

	limiton = setalarm;
	
	pulseMinhere = pulseMin;
	pulseMaxhere = pulseMax;

}

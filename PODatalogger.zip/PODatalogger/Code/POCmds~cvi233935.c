#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
 
#include <stdio.h>
#include <windows.h> 
#include "mpusbapi.h"


#include "picdriver.h"


extern DWORD SendReceivePacket(BYTE *SendData, DWORD SendLength, BYTE *ReceiveData,
                    DWORD *ReceiveLength, UINT SendDelay, UINT ReceiveDelay);

extern char SendData[];
extern DWORD SendLength;
extern DWORD SentDataLength;
extern DWORD SendDelay;
extern char ReceiveData[4];
extern DWORD ExpectedReceiveLength;
extern DWORD ReceiveLength;
extern DWORD ReceiveDelay;
extern BYTE send_buf[64],receive_buf[64];
extern DWORD RecvLength;



int Read(int * redChn, int * IRChn){
    send_buf[0] = 0xEF;      // Command
    
    RecvLength = 5; //set expected receive length 
    if (SendReceivePacket(send_buf,1,receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 5) && (receive_buf[0] == 0xEF))
        {
            *redChn = (receive_buf[2] & 0xFF )|((receive_buf[1]<<8) & 0xFF00);
			*IRChn = (receive_buf[4] & 0xFF )|((receive_buf[3]<<8) & 0xFF00);
        }
    }
    else
    {
        printf("USB Operation Failed\r\n");
	}

  return no_error;	
}
int setLEDReg(int redled, int IRled){
	
	if (redled > 1023)redled = 1023; 
	if (IRled > 1023)IRled = 1023;
	if (redled < 0)redled = 0;
	if (IRled < 0)IRled = 0;
	
	send_buf[0] = 0xF1;      // Command
    send_buf[2] = redled & 0xFF;     //the value
    send_buf[1] = (redled >> 8) &0xFF;
	send_buf[4] = IRled & 0xFF;     //the value
    send_buf[3] = (IRled >> 8) &0xFF;
	
    RecvLength = 5; //set expected receive length 
    if (SendReceivePacket(send_buf, 5, receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 5) && (receive_buf[0] == 0xF1))
        {
        }
    }
    else
    {    
        printf("USB Operation Failed\r\n");

	}
  
  return no_error;
}
int FingerPresent(void){
	send_buf[0] = 0xF2;      // Command
    
    RecvLength = 2; //set expected receive length 
    if (SendReceivePacket(send_buf,1,receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 2) && (receive_buf[0] == 0xF2))
        {
            if(receive_buf[1] == 'y')return(1);
        }
    }
    else
    {
        printf("USB Operation Failed\r\n");
	}
	
	return(0);
}

int SetIndicators(int indicator, int red, int blue, int green){
	char setting = 0;
	if(indicator == 1)setting = setting | 1;
	if(red == 1)setting = setting | 2;
	if(green == 1)setting = setting | 4;
	if(blue == 1)setting = setting | 8;
	
	send_buf[0] = 0xF3;      // Command
    send_buf[1] = setting;     //the value
    
    RecvLength = 2; //set expected receive length 
    if (SendReceivePacket(send_buf, 2, receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 2) && (receive_buf[0] == 0xF3))
        {
        }
    }
    else
    {    
        printf("USB Operation Failed\r\n");

	}
  
  return no_error;
}

//PulseOx Test and development Commands
int setDAC(int setting){
	send_buf[0] = 0xF4;      // Command
    send_buf[1] = setting & 0xFF;     //the value
    send_buf[2] = (setting >> 8) &0xFF;
	
    RecvLength = 3; //set expected receive length 
    if (SendReceivePacket(send_buf, 3, receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 3) && (receive_buf[0] == 0xF4))
        {
        }
    }
    else
    {    
        printf("USB Operation Failed\r\n");

	}
  
  return no_error;
}

int setPWMRed(int value){
	if(value > 1023) value = 1023;
	if(value < 0)value = 0;
    send_buf[0] = 0xF5;      // Command
    send_buf[2] = value & 0xFF;     //the value
    send_buf[1] = (value >> 8) & 0xFF;
	
    RecvLength = 3; //set expected receive length 
    if (SendReceivePacket(send_buf, 3, receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 3) && (receive_buf[0] == 0xF5))
        {
        }
    }
    else
    {    
        printf("USB Operation Failed\r\n");

	}
  
  return no_error;
}
int setPWMIR(int value){
	if(value > 1023) value = 1023;
	if(value < 0)value = 0;
    send_buf[0] = 0xF6;      // Command
    send_buf[2] = value & 0xFF;     //the value
    send_buf[1] = (value >> 8) &0xFF;
	
    RecvLength = 3; //set expected receive length 
    if (SendReceivePacket(send_buf, 3, receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 3) && (receive_buf[0] == 0xF6))
        {
        }
    }
    else
    {    
        printf("USB Operation Failed\r\n");

	}
  
  return no_error;	
}

int ReturnADC(int *ADC0, int *ADC1, int *ADC2)
{
     send_buf[0] = 0xF8;      // Command
    
    RecvLength = 7; //set expected receive length 
    if (SendReceivePacket(send_buf,1,receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 7) && (receive_buf[0] == 0xF8))
        {
            *ADC0 = (receive_buf[2] & 0xFF )|((receive_buf[1]<<8) & 0xFF00);
			*ADC1 = (receive_buf[4] & 0xFF )|((receive_buf[3]<<8) & 0xFF00); 
			*ADC2 = (receive_buf[6] & 0xFF )|((receive_buf[5]<<8) & 0xFF00); 
        }
    }
    else
    {
        printf("USB Operation Failed\r\n");
	}
	   return no_error;  
	
}

int ReturnRegisters(int *DCbias, int * redSetting, int * IRSetting){
    send_buf[0] = 0xF9;      // Command
    
    RecvLength = 7; //set expected receive length 
    if (SendReceivePacket(send_buf,1,receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 7) && (receive_buf[0] == 0xF9))
        {
            *DCbias = (receive_buf[2] & 0xFF )|((receive_buf[1]<<8) & 0xFF00);
			*redSetting = (receive_buf[4] & 0xFF )|((receive_buf[3]<<8) & 0xFF00); 
			*IRSetting = (receive_buf[6] & 0xFF )|((receive_buf[5]<<8) & 0xFF00); 
        }
    }
    else
    {
        printf("USB Operation Failed\r\n");
	}
	    return no_error;  
	
}

int read_TransImpedance (int *value)
{
     send_buf[0] = 0xFA;      // Command
    
    RecvLength = 3; //set expected receive length 
    if (SendReceivePacket(send_buf,1,receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 3) && (receive_buf[0] == 0xFA))
        {
            *value = (receive_buf[2] & 0xFF )|((receive_buf[1]<<8) & 0xFF00);
        }
    }
    else
    {
        printf("USB Operation Failed\r\n");
	}

  return no_error;
}


int read_ADC1 (int *value)
{
     send_buf[0] = 0xFB;      // Command
    
    RecvLength = 3; //set expected receive length 
    if (SendReceivePacket(send_buf,1,receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 3) && (receive_buf[0] == 0xFB))
        {
            *value = (receive_buf[2] & 0xFF )|((receive_buf[1]<<8) & 0xFF00);
        }
    }
    else
    {
        printf("USB Operation Failed\r\n");
	}

  return no_error;
}
int read_Output (int *value)
{
     send_buf[0] = 0xFC;      // Command
    
    RecvLength = 3; //set expected receive length 
    if (SendReceivePacket(send_buf,1,receive_buf,&RecvLength,1000,1000) == 1)
    {
        if ((RecvLength == 3) && (receive_buf[0] == 0xFC))
        {
            *value = (receive_buf[2] & 0xFF )|((receive_buf[1]<<8) & 0xFF00);
        }
    }
    else
    {
        printf("USB Operation Failed\r\n");
	}

  return no_error;
}


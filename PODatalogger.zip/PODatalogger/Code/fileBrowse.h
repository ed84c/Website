/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2011. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/


#ifndef FILEBROWSE_H
#define FILEBROWSE_H

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_FILEBROWSER                2       /* control type: tree, callback function: (none) */
#define  PANEL_OKBUTTON                   3       /* control type: command, callback function: OKCallback */
#define  PANEL_STRING                     5       /* control type: string, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK OKCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK QuitCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int write_csv_folder(char *filep);
//int browse_main (int argc, char *argv[]);
int browse_main (void);

#ifdef __cplusplus
    }
#endif
	
#endif

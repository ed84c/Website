
#include <ansi_c.h>
#include "POSigProc.h"

double xvals[2][15] = {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};

double Pulse[2][400];  


double y_prev[2] = {0,0};
double a = 0.9;
double x_prev[2] = {0,0};


double RedMax, RedMin, IRMax, IRMin, RedDC, IRDC;
double RedLEDBrightness, IRLEDBrightness = 900;

static double pulseCount;
static int pulseStatus = 0;
double SmoothPulse[4];
double PulseAverage = 0; 

static double xcoeffs[]  =
  { -0.0300398707, -0.0708376129, -0.0749721510, +0.0265132793,
    +0.2664664134, +0.5946310835, +0.8841845738, +1.0000000026,
    +0.8841845738, +0.5946310835, +0.2664664134, +0.0265132793,
    -0.0749721510, -0.0708376129, -0.0300398707,
  };

//#define USB_CONNECTED

#ifdef USB_CONNECTED

int getPulse(double * IRtrace, double * RedTrace, double * PulseRate, double * Ros){
	//This function must be called at exactly the sample rate - no more or less often!
	
	int value[2] = {0,0};
	double rawval[2];
	double dVal[2];
	double trace[2]; 
	double tracePLOT[2];
	double Kred = 0.1;
	double Kir = 0.1;
	double ZeroCrossing;
	int CrossingPoints[15];
	int n = 0;
	int i;

	double plotpoint = 0;
	
	double I1red, I2red, I1IR, I2IR;
	double RosValue;
	double TempPulseRate = 0;
	
	  //read_TransImpedance(&value); 
	Read(&value[0],&value[1]);
		
	rawval[0] = value[0];
	rawval[1] = value[1];

	//Find the DC values of the signals
	RedDC = 0.8*RedDC + 0.2 *rawval[0];
	IRDC = 0.8*IRDC + 0.2 *rawval[1];
	
	//Adjust the LED brightness to tend to the correct position
	if(RedDC > 800 || RedDC < 600 || IRDC > 800 || IRDC < 600){

		RedLEDBrightness = RedLEDBrightness + Kred * (700 - RedDC);
		IRLEDBrightness = IRLEDBrightness + Kir * (700 - RedDC);
		
		if(RedLEDBrightness > 1023)RedLEDBrightness = 1023; 
		if(RedLEDBrightness < 0)RedLEDBrightness = 0;
		if(IRLEDBrightness > 1023)IRLEDBrightness = 1023; 
		if(IRLEDBrightness < 0)IRLEDBrightness = 0;

		setLEDReg(RedLEDBrightness, IRLEDBrightness);
		
	}
	
	//Return fail if the values are too far out of range on this read
	  if(RedDC > 1020 || RedDC < 100 || IRDC > 1020 || IRDC < 100){
		return(0);
	  }
	  
  	  //shift values for FIR
	  for(i = 0; i<14; i++){
		xvals[0][i] = xvals[0][i+1];	  
	  	xvals[1][i] = xvals[1][i+1];
	  }
	  xvals[0][14] = rawval[0];
  	  xvals[1][14] = rawval[1];
	  
	  //Apply FIR filter
	  dVal[0] = 0;
	  dVal[1] = 0;
	  for (i = 0; i <= 14; i++){ 
		dVal[0] += (xcoeffs[i] * xvals[0][i]);
		dVal[1] += (xcoeffs[i] * xvals[1][i]);		  
	  }
	
	  //IIR Filter
	  trace[0] =  a*y_prev[0] + dVal[0] - x_prev[0];
	  trace[1] =  a*y_prev[1] + dVal[1] - x_prev[1];
	  x_prev[0] = dVal[0];
	  x_prev[1] = dVal[1];
	  y_prev[0] = trace[0];
  	  y_prev[1] = trace[1];

	  //Save the data to then process it for pulse rate and SaO2
	  //Find a local amplitude
	  RedMax = 0;
	  RedMin = 0;
	  IRMax = 0;
	  IRMin = 0;
	  
	  for(i = 150; i> 0; i--){
		Pulse[0][i] = Pulse[0][i-1];	  
	  	Pulse[1][i] = Pulse[1][i-1];
		if (Pulse[0][i] > RedMax)RedMax = Pulse[0][i];
		if (Pulse[0][i] < RedMin)RedMin = Pulse[0][i];
		if (Pulse[1][i] > IRMax)IRMax = Pulse[1][i];
		if (Pulse[1][i] < IRMin)IRMin = Pulse[1][i];
	  }
	  //Need to fully update signal but may want to max min across less to impreve response spee

	  Pulse[0][0] = -1*trace[0];
	  Pulse[1][0] = -1*trace[1];
  	 
	  //Plot the data
	   //Apply a scaling and invert - check this assumption?
	  tracePLOT[0] = -1 * (200/(RedMax - RedMin))*trace[0] + 100;
	  tracePLOT[1] =  -1 * (200/(IRMax - IRMin))*trace[1] - 100;
	  //Now find the pulse rate
	  //Know where the local midoint is - therefore find zero corssings
	  //Do it on just IR
	
	  //ZeroCrossing = (IRMax +  IRMin) * (3/4);
	  ZeroCrossing = 75  ;

	  
	  
	  if((tracePLOT[1] + 100) > 75){
			plotpoint = 1;
	 	if(pulseStatus == 0 && pulseCount > 5){
			pulseStatus = 1;
			TempPulseRate = (1/(0.014* pulseCount)) * 60;
			
			pulseCount = 0;
			
			
			//Do a 4 point moving average on the pulse
			PulseAverage = TempPulseRate;
			for(i = 2; i >= 0; i--){
				SmoothPulse[i+1] = SmoothPulse[i];
				PulseAverage = PulseAverage + SmoothPulse[i+1]; 
			}
			PulseAverage = PulseAverage / 4;
			SmoothPulse[0] = TempPulseRate;

		}
	  }else{
		  pulseStatus = 0;
	  	  plotpoint = 0;
	  }
	  pulseCount = pulseCount + 1;
	
	  
	  I1red= RedDC + RedMax;
	  I2red= RedDC + RedMin;  //as red min is -ve
	  I1IR = IRDC + IRMax; 
	  I2IR = IRDC + IRMin;
	  
	  RosValue = (I2red/I1red)/(I2IR/I1IR);
	
	  //Now put values into variables
	  *IRtrace= tracePLOT[1];
	  *RedTrace = tracePLOT[0]; 
	  *PulseRate = PulseAverage;
	  *Ros = RosValue;

	return(1);
}


int IsFingerPresent(void){
	//return(FingerPresent());
	return(1);
}

#endif

#ifndef USB_CONNECTED

int getPulse(double * IRtrace, double * RedTrace, double * PulseRate, double * Ros){

*PulseRate =  rand() % 20+ 70;

*Ros = rand() % 100;

*Ros = *Ros/200 + 0.5;

*IRtrace = rand() % 30 + 40;

*RedTrace = rand() % 30 + 40;

return 1;

}

int IsFingerPresent(void){
	return 1;
}
 

#endif





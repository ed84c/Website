/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2011. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_CALIBRATE                  2       /* control type: command, callback function: CalibrateOpen */
#define  PANEL_STOPLOG                    3       /* control type: command, callback function: stoplog_hit */
#define  PANEL_STARTLOG                   4       /* control type: command, callback function: startlog_hit */
#define  PANEL_ISFINGER                   5       /* control type: LED, callback function: (none) */
#define  PANEL_PulseAlarm                 6       /* control type: LED, callback function: (none) */
#define  PANEL_LOGGING                    7       /* control type: LED, callback function: (none) */
#define  PANEL_DECORATION_2               8       /* control type: deco, callback function: (none) */
#define  PANEL_SAO2                       9       /* control type: numeric, callback function: (none) */
#define  PANEL_txt_bpm                    10      /* control type: textMsg, callback function: (none) */
#define  PANEL_txt_perc                   11      /* control type: textMsg, callback function: (none) */
#define  PANEL_PULSE                      12      /* control type: numeric, callback function: (none) */
#define  PANEL_PULSEGRAPH                 13      /* control type: strip, callback function: (none) */
#define  PANEL_TIMER_DISPLAY              14      /* control type: timer, callback function: TIMER_DISPLAY */
#define  PANEL_LOGGRAPH                   15      /* control type: strip, callback function: (none) */
#define  PANEL_CSVLOCSTR                  16      /* control type: string, callback function: (none) */
#define  PANEL_MaxPulse                   17      /* control type: numeric, callback function: (none) */
#define  PANEL_MinPulse                   18      /* control type: numeric, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

#define  MENUBAR                          1
#define  MENUBAR_MenuFile                 2
#define  MENUBAR_MenuFile_MenuClose       3       /* callback function: Menu_Close */
#define  MENUBAR_MenuFile_MenuRefresh     4       /* callback function: Menu_Refresh */
#define  MENUBAR_MenuSettings             5
#define  MENUBAR_MenuSettings_MenuLogging 6       /* callback function: Menu_Logging */
#define  MENUBAR_MenuHelp                 7       /* callback function: Menu_Help */
#define  MENUBAR_MenuHelp_MenuHelp2       8       /* callback function: Menu_Help2 */
#define  MENUBAR_MenuHelp_MenuHelp4       9       /* callback function: Menu_Help4 */


     /* Callback Prototypes: */

int  CVICALLBACK CalibrateOpen(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK Menu_Close(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK Menu_Help(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK Menu_Help2(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK Menu_Help4(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK Menu_Logging(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK Menu_Refresh(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK startlog_hit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK stoplog_hit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TIMER_DISPLAY(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include "PulseOx_LogSettings.h"

static int panelHandle;
void Open_CSV_Panel(void);  
void setupalarm(int setalarm, int pulseMin, int pulseMax);

	int setalarm = 0;
	int minAlarm=0;
	int maxAlarm=0;

int LogSet_Main (void)
{

	if ((panelHandle = LoadPanel (0, "PulseOx_LogSettings.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK cmdChooseCSV (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			Open_CSV_Panel();
			break;
	}
	return 0;
}


int CVICALLBACK SetAlarms (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	
	

	
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(panelHandle,PANEL_SetAlarms,&setalarm);
			GetCtrlVal(panelHandle,PANEL_UpperPulse,&maxAlarm);
			GetCtrlVal(panelHandle,PANEL_LowerPulse,&minAlarm);
			
		
				if ((int)setalarm == 1)
			{
				SetCtrlAttribute(panelHandle,PANEL_UpperPulse,ATTR_DIMMED,0);
				SetCtrlAttribute(panelHandle,PANEL_LowerPulse,ATTR_DIMMED,0); 
			}
				else
				{
					SetCtrlAttribute(panelHandle,PANEL_UpperPulse,ATTR_DIMMED,1);
					SetCtrlAttribute(panelHandle,PANEL_LowerPulse,ATTR_DIMMED,1); 
				}
				break;
	}
	return 0;
}

int CVICALLBACK LowerPulse (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK UpperPulse (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK cmdOK (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			HidePanel(panelHandle);
			
			GetCtrlVal(panelHandle,PANEL_UpperPulse,&maxAlarm);
			GetCtrlVal(panelHandle,PANEL_LowerPulse,&minAlarm);
		
			
			setupalarm((int)setalarm, (int)minAlarm,(int)maxAlarm);
				
				ResumeTimerCallbacks();
			break;
	}
	return 0;
}

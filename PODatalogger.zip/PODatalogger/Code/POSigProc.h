#ifndef POSIGPROC_H
#define POSIGPROC_H

  #include <userint.h>
//#include "pictest.h"
#include "picdriver.h"  

#include "POCmds.h"

int getPulse(double * IRtrace, double * RedTrace, double * PulseRate, double * Ros);


int IsFingerPresent(void);

#endif

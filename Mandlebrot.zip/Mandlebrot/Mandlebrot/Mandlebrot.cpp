#include "stdafx.h"
#include <iostream>
#include <fstream>



using namespace std;

int escape_iterations(double c_real, double c_imag, int max_iterations);

int main() {

int no_iterations = 0;
double a = 0; 
double b = 0;

//cout << "Complex numbers to be entered in form 'a + bj'" << endl;
//cout << "a = " << endl;
//cin >> a;
//cout << "b = " << endl;
//cin >> b;

//int max_col = 9;
//double max_val = 2;

//a = -max_val;
//for (int col_index = 0 ; col_index < (width); col_index++)
//{
//  cout << a << endl;
//  a = a + max_val/(width)*2;
  
//}

double max_val = 2;

//no_iterations   = escape_iterations(a , b , 0);

//cout << "Number of iterations until escape is: " << no_iterations << endl;

int pass_count = 0;

 ofstream file("test.pgm");  // open the output stream
int width = 0;
int height = 0;
int max_iterations = 0;

    const int max_intensity = 255;
    
	a = -max_val;
	b = -max_val;

    // Write the PGM header
    file << "P3" << endl << width << " " << height << endl << max_intensity << endl;

    cout << "Enter Width" << endl;
    cin >> width;	
    cout << "Enter Height" << endl;
	cin >> height;
	cout << "Max Iterations" << endl;
    cin >> max_iterations;

	
    // Go through in raster order (row by row)
    for (int row=0; row<height-1; ++row) 
    {
	a = -max_val;
	
        for (int col=0; col<width; ++col)
        {
       no_iterations   = escape_iterations(a, b , max_iterations);            
	   a = a + max_val/(width-1)*2;
	   cout << no_iterations << " ";
	   file << (no_iterations/1000)*255  << " ";
	   	if (no_iterations == max_iterations)
			pass_count = pass_count+1;
        }
        // Put an end-line at the end of each row 
        // (not required by PGM, but makes it easier to check the output)
	file << endl;
    b = b + max_val/(height-1)*2;
	}
    cout << "This text will appear on the console" << endl;
    
    // The file will be automatically closed at the end of main().

cout << "The Pass Count is : " << pass_count << endl;





}

int escape_iterations(double c_real, double c_imag, int max_iterations)
{

double r_sqrd = 0;
double z[2] = {0,0};  //This is the complex number that increases in size during the summing operation
double z1[2]; //This is the first version of the complex number (ie. "c")
double z_prev[2] = {0,0};


z1[0] =c_real;
z1[1] = c_imag; //The array consists of location 1 as "a" and location 2 as "b" in a + bj


r_sqrd = c_real*c_real + c_imag*c_imag;


//int r = 0;
int i = 0;

//cout<< z1[0] << " , " << z1[1] << endl;

while ((r_sqrd < 4) && (i < max_iterations))
{

//cout<< z[0] << " , " << z[1] << endl;

z[0] = z1[0] + (z_prev[0]*z_prev[0] - z_prev[1]*z_prev[1]);
z[1] = z1[1] + 2*(z_prev[1]*z_prev[0]);
// since z^2 = (a + bj)*(a + bj) = (a*a - b*b) + (a*b + b*a)j 
r_sqrd = z[0]*z[0] + z[1]*z[1];
z_prev[0] = z[0];
z_prev[1] = z[1];
i++;
}


return i;

}
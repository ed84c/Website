load('tyredata2.mat')

%%Car Details%%
a = 1 %Distance from COG to front wheel centerline 
b = 2 %Distance from COG to rear wheel centerline
Tf = 1.3 %Front track
Tr = 1.3 %Rear track
sf = 0.8 %Distance between front springs
sr = 0.8 %Distance between rear springs
epsilon = 0; %Angle of roll center line
hcom = 0.3; %Height of COM
hf = 0.3; %Height of roll center at front
hr = hf + (a+b)*sin(epsilon); %Height of roll center at rear
h1 = hcom-hf + a*sin(epsilon); %Height of COM above roll center.
WB = a+b; %Wheel base

%%Suspension Setup%%
Cf = 16 %Cornering stiffness N/rad (front)
Cr = 16 %Cornering stiffness N/rad (rear)
ksf = 40000 %front spring rates
ksr = 40000 %rear spring rates

%%Driver%%
u_demand = 0.1; %Demanded velocity at first instance
a_demand1 = 1; %Demanded accn at 1nd instance (ramp): for 5 sec
a_demand2 = -1; %Demanded accn at 1nd instance (ramp): for 5 sec



%%%Quarter Car Model%%%
Csf = 250 %Damper coefficient front
Csr = 250  %Damper coefficient rear
kt =3000 %Tyre stiffness
Mu=10; %Unsprung mass
Ms=50; %Sprung mass
Cst=250%Tyre damping coefficient
G0 = 12.50000/1500;
V0 = 0.06;

%%Static Corner Weights%%
mFL=50;
mFR=50;
mRL=50;
mRR=50;

%%Aero%%
Cl=2.57 %Lift coefficient
Cd=1.33 %Coefficient of drag
A=1.35 %Frontal area
aero_balance=0.4 %balance of downforce F:R
rho=1%air density
EFKHunt 2013.

The model in its supplied state will not work, some required tyre data is not included in this package, as including the FSAE tyre data  as it would contravine the TTC licensing agreement.
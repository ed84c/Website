// TSP2.cpp : Defines the entry point for the application.
//
#include "stdafx.h"
#include <iostream>    // for cin, cout, etc.
#include <vector>      // for storing polynomials
#include <cmath>
#include <numeric>
#include <GL/glut.h>
#include <GL/glu.h>
using namespace std;  // to refer to the above without 'std::' prefix

#include "stdafx.h"
#include "TSP2.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_TSP2, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TSP2));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TSP2));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_TSP2);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: Add any drawing code here...
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

int main()
{
double CoOrds[31][3]; //Contains the co-ordinates of each location. The array contains an identifier ([n][0]), an x ([n][1]), and a y ([n][2])
double Curr_connector_length = 999999;//A variable to store the lengths of connectors dynamically as each is checked
double Prev_connector_length = 999999; //As above, but this is used so the loop can compare the new connector calculated to the previous one to pick the shortest
int Curr_connector[2];// The 2 points the current connector is connecting
int Connected[31] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; // An array storing which verticies have been visited, and which haven't
double total_length = 0; //the running total lenght of the journey
int route[31] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; //Contains the route in order visited e.g. Route(1) = 1, Route(2) = 4, Route(3) = 10
int Closest_vertex; //Contains the number of the current closest vertex

CoOrds[0][0] = 1;
CoOrds[0][1] = 6*190;
CoOrds[0][2] = 5.2*190;

CoOrds[1][0] = 2;
CoOrds[1][1] = 0.5*190;
CoOrds[1][2] = 4.7*190;

CoOrds[2][0] = 3;
CoOrds[2][1] = 0.9*190;
CoOrds[2][2] = 6.1*190;

CoOrds[3][0] = 4;
CoOrds[3][1] = 190;
CoOrds[3][2] = 8.5*190;

CoOrds[4][0] = 5;
CoOrds[4][1] = 3*190;
CoOrds[4][2] = 4*190;

CoOrds[5][0] = 6;
CoOrds[5][1] = 3.5*190;
CoOrds[5][2] = 5.4*190;

CoOrds[6][0] = 7;
CoOrds[6][1] = 4.3*190;
CoOrds[6][2] = 6.6*190;

CoOrds[7][0] = 8;
CoOrds[7][1] = 4.4*190;
CoOrds[7][2] = 9.3*190;

CoOrds[8][0] = 9;
CoOrds[8][1] = 4.4*190;
CoOrds[8][2] = 9.4*190;

CoOrds[9][0] = 10;
CoOrds[9][1] = 5.5*190;
CoOrds[9][2] = 12.5*190;

CoOrds[10][0] = 11;
CoOrds[10][1] = 5.2*190;
CoOrds[10][2] = 4.5*190;

CoOrds[11][0] = 12;
CoOrds[11][1] = 6*190;
CoOrds[11][2] = 4.5*190;

CoOrds[12][0] = 13;
CoOrds[12][1] = 5.1*190;
CoOrds[12][2] = 5.2*190;

CoOrds[13][0] = 14;
CoOrds[13][1] = 0.31*190;
CoOrds[13][2] = 3.5*190;

CoOrds[14][0] = 15;
CoOrds[14][1] = 5.2;
CoOrds[14][2] = 6.4;

CoOrds[15][0] = 16;
CoOrds[15][1] = 5.6*190;
CoOrds[15][2] = 6.5*190;

CoOrds[16][0] = 17;
CoOrds[16][1] = 5.2*190;
CoOrds[16][2] = 9.5*190;

CoOrds[17][0] = 18;
CoOrds[17][1] = 5.2*190;
CoOrds[17][2] = 10.8*190;

CoOrds[18][0] = 19;
CoOrds[18][1] = 8.6*190;
CoOrds[18][2] = 2.8*190;

CoOrds[19][0] = 20;
CoOrds[19][1] = 8.2*190;
CoOrds[19][2] = 5*190;

CoOrds[20][0] = 21;
CoOrds[20][1] = 8.5*190;
CoOrds[20][2] = 5.8*190;

CoOrds[21][0] = 22;
CoOrds[21][1] = 8.1*190;
CoOrds[21][2] = 6.2*190;

CoOrds[22][0] = 23;
CoOrds[22][1] = 7.0*190;
CoOrds[22][2] = 7.6*190;

CoOrds[23][0] = 24;
CoOrds[23][1] = 7.1*190;
CoOrds[23][2] = 6.9*190;

CoOrds[24][0] = 25;
CoOrds[24][1] = 6*190;
CoOrds[24][2] = 7.5*190;

CoOrds[25][0] = 26;
CoOrds[25][1] = 7.1*190;
CoOrds[25][2] = 11.0*190;

CoOrds[26][0] = 27;
CoOrds[26][1] = 1.4*190;
CoOrds[26][2] = 10.2*190;

CoOrds[27][0] = 28;
CoOrds[27][1] = 10.2*190;
CoOrds[27][2] = 4.8*190;

CoOrds[28][0] = 29;
CoOrds[28][1] = 9.2*190;
CoOrds[28][2] = 7.3*190;

CoOrds[29][0] = 30;
CoOrds[29][1] = 8.2*190;
CoOrds[29][2] = 8.9*190;

CoOrds[30][0] = 31;
CoOrds[30][1] = 8.6*190;
CoOrds[30][2] = 11.0*190;



int i = 0;
int l = 1;
route[0] = 1;

//Loop goes through point finding shortest connectors
while (Connected[0] + Connected[1] + Connected[2] + Connected[3] + Connected[4] + Connected[5] + Connected[6] + Connected[7] + Connected[8] + Connected[9] + Connected[10] + Connected[11] + Connected[12] + Connected[13] + Connected[14] + Connected[15] + Connected[16] + Connected[17] + Connected[18] + Connected[19] + Connected[20] + Connected[21] + Connected[22] + Connected[23] + Connected[24] + Connected[25] + Connected[26] + Connected[27] + Connected[28] + Connected[29] + Connected[30] <31) //Go through each point
    {
	  for (int k =0; k < 31; k++)//Find shortest connector to this point
        {   
        if ((k!=i) && (Connected[k] !=1) )
			Curr_connector_length = sqrt(double((CoOrds[i][1] - CoOrds[k][1])*(CoOrds[i][1] - CoOrds[k][1])) + double((CoOrds[i][2] - CoOrds[k][2])*(CoOrds[i][2] - CoOrds[k][2])));
	
        if ((Prev_connector_length > Curr_connector_length) && (k!=i) && (Connected[k] !=1))
            {
            Prev_connector_length = Curr_connector_length;
			Closest_vertex = k;
            }
        }
	  cout << "Closest vertex to " << i << " is " << Closest_vertex << endl;
	  Connected[0] = 1;
	  total_length= total_length + Prev_connector_length;
	  Connected[Closest_vertex] = 1;
	  route[l] = CoOrds[Closest_vertex][0];
	  l++;
	  i = Closest_vertex;
	  Prev_connector_length = 9999999;
    }
    
	route[30] = CoOrds[Closest_vertex][0];

	cout << "Total Tour Length: " << total_length << endl << endl;
	cout << route[0] << " to " << route[1] << " to " << route[2] << " to " << route[3] << " to " << route[4] << " to " << route[5] << " to " << route[6] << " to " << route[7] << " to "  << route[8] << " to " << route[9] << " to " << route[10] << " to " << route[11] << " to " << route[12] << " to " << route[13] << " to " << route[14] << " to " << route[15]  << " to " << route[16] << " to " << route[17] << " to " << route[18] << " to " << route[19] << " to " << route[20] << " to " << route[21] << " to " << route[22] << " to " << route[23]  << route[24] << " to " << route[25] << " to " << route[26] << " to " << route[27] << " to " << route[28] << " to " << route[29] << " to " << route[30] << endl;
	cout << Connected[0] << Connected [1] << Connected[2] << Connected[3] << endl;

 // next code will draw a line at starting and ending coordinates specified by glVertex3f
glutInit;
glutCreateWindow;
glBegin(GL_LINES);
glVertex3f(100.0f, 100.0f, 0.0f); // origin of the line
glVertex3f(200.0f, 140.0f, 5.0f); // ending point of the line


}


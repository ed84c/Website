Fvo=0.1;
Stroke=0.1;
KL=100;
OilBM=0.0000000014;
Ap=0.00000167;
Mp=0.5;
Fvc=100;
sim('moog_gearshift);